@file:OptIn(ExperimentalFoundationApi::class)

package os.smth.launcher

import android.content.Context
import android.os.BatteryManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val MONO = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })

/** Monochrome app tile: 1.5dp outline, press = scale 0.9 + red outline. */
@Composable
fun AppIcon(app: AppEntry, size: Dp, pinned: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.9f else 1f, label = "press")
    val shape = RoundedCornerShape(size * 0.3f)
    Box(
        Modifier.size(size)
            .graphicsLayer { scaleX = s; scaleY = s }
            .clip(shape).background(Color.Black)
            .border(1.5.dp, if (pressed) RED else Color.White.copy(alpha = 0.45f), shape)
            .combinedClickable(interactionSource = src, indication = null, onClick = onClick, onLongClick = onLongClick),
        contentAlignment = Alignment.Center,
    ) {
        Image(app.icon, app.label, Modifier.fillMaxSize().padding(size * 0.16f), colorFilter = MONO)
        if (pinned) Box(Modifier.align(Alignment.TopEnd).padding(5.dp).size(6.dp).background(RED, CircleShape))
    }
}

@Composable
private fun HomeLayer(modifier: Modifier) {
    val ctx = LocalContext.current
    val now by produceState(initialValue = Date()) { while (true) { value = Date(); delay(1000) } }
    val time = SimpleDateFormat("HH:mm", Locale.US).format(now)
    val date = SimpleDateFormat("EEE dd MMM", Locale.US).format(now)
    val battery = remember(now) {
        (ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        DotText(time, 9.dp)
        Spacer(Modifier.height(20.dp))
        DotText(date, 3.5.dp)
        Spacer(Modifier.height(14.dp))
        DotText("BAT $battery", 3.dp, off = null)
    }
}

@Composable
private fun Dock(apps: List<AppEntry>, onLaunch: (AppEntry) -> Unit, onPin: (AppEntry) -> Unit, modifier: Modifier) {
    val shape = RoundedCornerShape(32.dp)
    Row(
        modifier.clip(shape).background(Color(0xCC121212)).border(1.dp, Color(0x22FFFFFF), shape)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        apps.forEach { app -> AppIcon(app, 56.dp, false, { onLaunch(app) }, { onPin(app) }) }
    }
}

@Composable
private fun Drawer(
    apps: List<AppEntry>, dockKeys: List<String>, query: String, onQuery: (String) -> Unit,
    dragMod: Modifier, onLaunch: (AppEntry) -> Unit, onPin: (AppEntry) -> Unit, modifier: Modifier,
) {
    val results = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query, ignoreCase = true) }
    }
    Column(modifier.background(Color(0xF2000000)).padding(horizontal = 16.dp)) {
        // drag handle: swipe down here (or press Back) to close
        Column(Modifier.fillMaxWidth().then(dragMod).padding(top = 14.dp, bottom = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.width(44.dp).height(4.dp).background(Color.White.copy(alpha = 0.4f), CircleShape))
            Spacer(Modifier.height(12.dp))
            DotText("APPS", 4.dp)
        }
        val shape = RoundedCornerShape(24.dp)
        BasicTextField(
            value = query, onValueChange = onQuery, singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
            cursorBrush = SolidColor(RED),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { results.firstOrNull()?.let(onLaunch) }),
            modifier = Modifier.fillMaxWidth().border(1.5.dp, Color.White.copy(alpha = 0.35f), shape).padding(horizontal = 18.dp, vertical = 12.dp),
            decorationBox = { inner ->
                if (query.isEmpty()) BasicText("Search apps", style = TextStyle(color = Color.White.copy(alpha = 0.4f), fontSize = 16.sp))
                inner()
            },
        )
        Spacer(Modifier.height(16.dp))
        LazyVerticalGrid(
            GridCells.Fixed(4), Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            items(results, key = { key(it) }) { app ->
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    AppIcon(app, 60.dp, key(app) in dockKeys, { onLaunch(app) }, { onPin(app) })
                    Spacer(Modifier.height(6.dp))
                    BasicText(
                        app.label, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = TextStyle(color = Color.White, fontSize = 11.sp, textAlign = TextAlign.Center),
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }
            }
        }
    }
}

@Composable
fun LauncherRoot(
    apps: List<AppEntry>, dockKeys: List<String>, homeSignal: Int,
    onLaunch: (AppEntry) -> Unit, onTogglePin: (AppEntry) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val progress = remember { Animatable(0f) }       // 0 = home, 1 = drawer open
    var heightPx by remember { mutableFloatStateOf(1f) }
    var query by remember { mutableStateOf("") }

    fun settle(target: Float) = scope.launch {
        progress.animateTo(target, spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow))
        if (target == 0f) query = ""
    }

    LaunchedEffect(homeSignal) { if (progress.value > 0f) settle(0f) }
    BackHandler(progress.value > 0.01f) { settle(0f) }

    val dragState = rememberDraggableState { dy ->
        scope.launch { progress.snapTo((progress.value - dy / (heightPx * 0.8f)).coerceIn(0f, 1f)) }
    }
    val dragMod = Modifier.draggable(dragState, Orientation.Vertical, onDragStopped = { v ->
        settle(if (v < -900f) 1f else if (v > 900f) 0f else if (progress.value > 0.5f) 1f else 0f)
    })

    val dockApps = remember(apps, dockKeys) { dockKeys.mapNotNull { k -> apps.firstOrNull { key(it) == k } } }
    val launch: (AppEntry) -> Unit = { app ->
        onLaunch(app)
        scope.launch { delay(350); progress.snapTo(0f); query = "" }
    }

    Box(Modifier.fillMaxSize().background(Color.Black).onSizeChanged { heightPx = it.height.toFloat() }) {
        Box(Modifier.fillMaxSize().then(dragMod).windowInsetsPadding(WindowInsets.systemBars)) {
            HomeLayer(
                Modifier.fillMaxSize().graphicsLayer {
                    alpha = 1f - progress.value
                    scaleX = 1f - 0.08f * progress.value; scaleY = scaleX
                },
            )
            Column(Modifier.align(Alignment.BottomCenter).graphicsLayer { alpha = 1f - progress.value }, horizontalAlignment = Alignment.CenterHorizontally) {
                DotText("SWIPE UP", 2.5.dp, off = null, on = Color.White.copy(alpha = 0.45f))
                Spacer(Modifier.height(14.dp))
                Dock(dockApps, launch, onTogglePin, Modifier)
                Spacer(Modifier.height(16.dp))
            }
        }
        Drawer(
            apps, dockKeys, query, { query = it }, dragMod, launch, onTogglePin,
            Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars).graphicsLayer {
                translationY = (1f - progress.value) * heightPx
                alpha = progress.value
            },
        )
    }
}
