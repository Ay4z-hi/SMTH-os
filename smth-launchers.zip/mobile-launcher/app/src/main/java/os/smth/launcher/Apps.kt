package os.smth.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppEntry(val label: String, val pkg: String, val cls: String, val icon: ImageBitmap)

fun key(a: AppEntry) = "${a.pkg}/${a.cls}"

fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            AppEntry(
                it.loadLabel(pm).toString(),
                it.activityInfo.packageName,
                it.activityInfo.name,
                it.loadIcon(pm).toBitmap(128, 128).asImageBitmap(),
            )
        }
        .sortedBy { it.label.lowercase() }
}

fun launchApp(ctx: Context, app: AppEntry) {
    val i = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setClassName(app.pkg, app.cls)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    try { ctx.startActivity(i) } catch (_: Exception) { }
}

/** Phone, messages, browser, camera: whatever the user's defaults are. */
fun defaultDock(ctx: Context, apps: List<AppEntry>): List<String> {
    val pm = ctx.packageManager
    val probes = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent(Intent.ACTION_VIEW, Uri.parse("sms:")),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
        Intent(MediaStore.ACTION_IMAGE_CAPTURE),
    )
    val picked = probes
        .mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
        .distinct()
        .mapNotNull { p -> apps.firstOrNull { it.pkg == p } }
        .map { key(it) }
    return (picked + apps.map { key(it) }.filter { it !in picked }).take(4)
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("smth", Context.MODE_PRIVATE)
    fun dock(c: Context): List<String>? =
        sp(c).getString("dock", null)?.split("|")?.filter { it.isNotEmpty() }
    fun saveDock(c: Context, list: List<String>) {
        sp(c).edit().putString("dock", list.joinToString("|")).apply()
    }
}
