package os.smth.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val apps = mutableStateOf<List<AppEntry>>(emptyList())
    private val dock = mutableStateOf<List<String>>(emptyList())
    private val homeSignal = mutableIntStateOf(0)

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { reload() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_EXPORTED)
        reload()
        setContent {
            LauncherRoot(
                apps = apps.value,
                dockKeys = dock.value,
                homeSignal = homeSignal.intValue,
                onLaunch = { launchApp(this, it) },
                onTogglePin = { togglePin(it) },
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        homeSignal.intValue++   // Home pressed: close the drawer
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        super.onDestroy()
    }

    private fun reload() {
        lifecycleScope.launch(Dispatchers.Default) {
            val list = loadApps(this@MainActivity)
            val d = Prefs.dock(this@MainActivity) ?: defaultDock(this@MainActivity, list)
            withContext(Dispatchers.Main) { apps.value = list; dock.value = d }
        }
    }

    private fun togglePin(app: AppEntry) {
        val k = key(app)
        val cur = dock.value
        val next = if (k in cur) cur - k else (cur + k).takeLast(5)
        dock.value = next
        Prefs.saveDock(this, next)
    }
}
