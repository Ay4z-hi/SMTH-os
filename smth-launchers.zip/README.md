# SMTH Launchers

| Part | Tech | Output |
|---|---|---|
| `mobile-launcher/` | Kotlin + Jetpack Compose (real Android HOME app) | `smth-launcher.apk` |
| `desktop-launcher/` | Rust + egui/eframe (one code-base) | `smth-start.exe` (Windows), `smth-start` (Linux x86_64) |

## Build in the browser (GitHub Actions)
1. Unzip, upload everything into your SMTH-os repo root (keep `.github/`), commit.
2. Actions -> **Build SMTH Launchers** -> Run workflow (it also runs when these folders change).
3. Download artifacts: `smth-launcher-apk`, `smth-start-linux-x86_64`, `smth-start-windows-x86_64`.

## Install the APK on your Samsung
1. Download the artifact zip, unzip, open `smth-launcher.apk`, allow "Install unknown apps" for your file manager/browser.
2. Press Home -> choose **SMTH Launcher** -> Always (or Settings -> Apps -> Choose default apps -> Home app).
3. To go back: same menu, pick One UI Home.

## Using it
**Mobile:** swipe up (or drag) for the app drawer, drag the handle down or press Back to close. Type to search, keyboard Search button launches the first hit. Long-press any icon to add/remove it from the dock (max 5).
**Desktop:** run `smth-start`. Type to search, arrows move, Enter launches, Esc closes, right-click pins/unpins. On Windows it also puts an icon in the tray (menu: Open / Quit) and hides when it loses focus.

## Honest status
- Neither project has been compiled yet (no Android/Rust toolchain or network where this was written). Expect to fix a few compile errors on the first CI run; send the log.
- Desktop app icons are dot-matrix letter tiles, not the real app icons (reading icon themes / .lnk icons is a later step).
- Windows tray is untested; "win-tab taskbar integration" is NOT included: on SMTH OS the taskbar is waybar, and window-group data will come from `smthd` once it exists.
- The Windows `.exe` lists Start Menu shortcuts; the Linux build reads `.desktop` files.
- The APK is debug-signed (fine for sideloading, not for Play Store).
- Gestures: swipe-up drawer and drag-down close are implemented; no notification-shade or double-tap-to-lock (needs extra permissions).
