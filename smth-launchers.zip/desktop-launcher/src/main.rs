#![cfg_attr(windows, windows_subsystem = "windows")]

mod apps;
mod dotfont;
mod tray;

use apps::App;
use eframe::egui::{
    self, pos2, vec2, Align2, Color32, FontId, Frame, Key, Modifiers, Rect, Sense, Stroke,
};
use dotfont::RED;
use std::path::PathBuf;
use std::time::Duration;

const COLS: usize = 5;
const CELL_W: f32 = 116.0;
const WIN: [f32; 2] = [660.0, 740.0];

struct Start {
    apps: Vec<App>,
    pinned: Vec<String>,
    query: String,
    sel: usize,
    centered: bool,
    had_focus: bool,
    tray: Option<tray::Tray>,
}

fn config_dir() -> PathBuf {
    let base = std::env::var("APPDATA")
        .or_else(|_| std::env::var("XDG_CONFIG_HOME"))
        .or_else(|_| std::env::var("HOME").map(|h| format!("{h}/.config")))
        .unwrap_or_else(|_| ".".into());
    PathBuf::from(base).join("smth")
}

fn load_pinned() -> Vec<String> {
    std::fs::read_to_string(config_dir().join("pinned.txt"))
        .map(|s| s.lines().map(|l| l.to_string()).filter(|l| !l.is_empty()).collect())
        .unwrap_or_default()
}

fn save_pinned(p: &[String]) {
    let dir = config_dir();
    let _ = std::fs::create_dir_all(&dir);
    let _ = std::fs::write(dir.join("pinned.txt"), p.join("\n"));
}

fn short(s: &str) -> String {
    if s.chars().count() > 14 {
        let t: String = s.chars().take(13).collect();
        format!("{t}…")
    } else {
        s.to_string()
    }
}

impl Start {
    fn new(cc: &eframe::CreationContext<'_>) -> Self {
        let mut v = egui::Visuals::dark();
        v.panel_fill = Color32::BLACK;
        v.window_fill = Color32::BLACK;
        v.extreme_bg_color = Color32::from_rgb(0x12, 0x12, 0x12);
        v.selection.bg_fill = RED;
        v.widgets.hovered.bg_stroke = Stroke::new(1.5, RED);
        v.widgets.active.bg_stroke = Stroke::new(1.5, RED);
        cc.egui_ctx.set_visuals(v);
        Self {
            apps: apps::load(),
            pinned: load_pinned(),
            query: String::new(),
            sel: 0,
            centered: false,
            had_focus: false,
            tray: tray::new(),
        }
    }

    /// With a tray icon the menu hides; without one it exits.
    fn close(&mut self, ctx: &egui::Context) {
        if self.tray.is_some() {
            ctx.send_viewport_cmd(egui::ViewportCommand::Visible(false));
            self.query.clear();
            self.sel = 0;
        } else {
            ctx.send_viewport_cmd(egui::ViewportCommand::Close);
        }
    }

    fn poll_tray(&mut self, ctx: &egui::Context) {
        let Some(t) = &self.tray else { return };
        ctx.request_repaint_after(Duration::from_millis(250));
        match t.poll() {
            Some(tray::Cmd::Open) => {
                ctx.send_viewport_cmd(egui::ViewportCommand::Visible(true));
                ctx.send_viewport_cmd(egui::ViewportCommand::Focus);
                self.query.clear();
                self.sel = 0;
                self.had_focus = false;
            }
            Some(tray::Cmd::Quit) => std::process::exit(0),
            None => {}
        }
    }
}

fn draw_cell(ui: &mut egui::Ui, app: &App, selected: bool, reveal: bool, pinned: bool) -> (bool, bool) {
    let (rect, resp) = ui.allocate_exact_size(vec2(CELL_W, 104.0), Sense::click());
    if reveal {
        ui.scroll_to_rect(rect, None);
    }
    let hot = selected || resp.hovered();
    let grow = if resp.hovered() { 2.0 } else { 0.0 };
    let tile = Rect::from_center_size(pos2(rect.center().x, rect.top() + 36.0), vec2(56.0, 56.0)).expand(grow);
    let p = ui.painter();
    p.rect_filled(tile, 16.0, Color32::BLACK);
    p.rect_stroke(tile, 16.0, Stroke::new(1.5, if hot { RED } else { Color32::from_gray(150) }));
    let letter: String = app.name.chars().next().map(|c| c.to_string()).unwrap_or_default();
    dotfont::draw(
        p, &letter, pos2(tile.center().x - 10.0, tile.center().y - 14.0), 4.0,
        Color32::WHITE, Some(Color32::from_gray(28)),
    );
    if pinned {
        p.circle_filled(pos2(tile.right() - 8.0, tile.top() + 8.0), 3.0, RED);
    }
    p.text(
        pos2(rect.center().x, rect.top() + 72.0), Align2::CENTER_TOP, short(&app.name),
        FontId::proportional(12.0), if hot { Color32::WHITE } else { Color32::from_gray(200) },
    );
    (resp.clicked(), resp.secondary_clicked())
}

#[allow(clippy::too_many_arguments)]
fn grid(
    ui: &mut egui::Ui, idxs: &[usize], offset: usize, apps: &[App], sel: usize, moved: bool,
    pinned: &[String], launch: &mut Option<usize>, pin: &mut Option<usize>,
) {
    for (row, chunk) in idxs.chunks(COLS).enumerate() {
        ui.horizontal(|ui| {
            ui.spacing_mut().item_spacing = vec2(6.0, 6.0);
            for (c, &ai) in chunk.iter().enumerate() {
                let global = offset + row * COLS + c;
                let (clicked, secondary) =
                    draw_cell(ui, &apps[ai], global == sel, moved && global == sel, pinned.contains(&apps[ai].name));
                if clicked { *launch = Some(ai); }
                if secondary { *pin = Some(ai); }
            }
        });
    }
}

fn section(ui: &mut egui::Ui, title: &str) {
    ui.add_space(8.0);
    let (r, _) = ui.allocate_exact_size(vec2(ui.available_width(), 18.0), Sense::hover());
    dotfont::draw(ui.painter(), title, r.left_top(), 2.2, Color32::from_gray(170), None);
    ui.add_space(6.0);
}

impl eframe::App for Start {
    fn clear_color(&self, _v: &egui::Visuals) -> [f32; 4] {
        [0.0, 0.0, 0.0, 0.0]
    }

    fn update(&mut self, ctx: &egui::Context, _f: &mut eframe::Frame) {
        self.poll_tray(ctx);

        // Center horizontally, sit just above the taskbar.
        if !self.centered {
            if let Some(m) = ctx.input(|i| i.viewport().monitor_size) {
                let x = ((m.x - WIN[0]) / 2.0).max(0.0);
                let y = (m.y - WIN[1] - 64.0).max(0.0);
                ctx.send_viewport_cmd(egui::ViewportCommand::OuterPosition(pos2(x, y)));
                self.centered = true;
            }
        }

        // Build the visible, ordered list.
        let q = self.query.to_lowercase();
        let mut pinned_idx: Vec<usize> = Vec::new();
        let mut rest: Vec<usize> = Vec::new();
        if q.is_empty() {
            for name in &self.pinned {
                if let Some(i) = self.apps.iter().position(|a| &a.name == name) {
                    pinned_idx.push(i);
                }
            }
            rest = (0..self.apps.len()).filter(|i| !pinned_idx.contains(i)).collect();
        } else {
            rest = (0..self.apps.len()).filter(|&i| self.apps[i].name.to_lowercase().contains(&q)).collect();
            rest.sort_by_key(|&i| !self.apps[i].name.to_lowercase().starts_with(&q));
        }
        let n_pinned = pinned_idx.len();
        let order: Vec<usize> = pinned_idx.iter().chain(rest.iter()).copied().collect();
        let n = order.len();

        // Keyboard navigation (consume keys so the search box doesn't move its cursor).
        let (esc, enter, left, right, up, down) = ctx.input_mut(|i| {
            (
                i.consume_key(Modifiers::NONE, Key::Escape),
                i.consume_key(Modifiers::NONE, Key::Enter),
                i.consume_key(Modifiers::NONE, Key::ArrowLeft),
                i.consume_key(Modifiers::NONE, Key::ArrowRight),
                i.consume_key(Modifiers::NONE, Key::ArrowUp),
                i.consume_key(Modifiers::NONE, Key::ArrowDown),
            )
        });
        let mut moved = false;
        if n > 0 {
            if right { self.sel = (self.sel + 1).min(n - 1); moved = true; }
            if left { self.sel = self.sel.saturating_sub(1); moved = true; }
            if down { self.sel = (self.sel + COLS).min(n - 1); moved = true; }
            if up { self.sel = self.sel.saturating_sub(COLS); moved = true; }
            if self.sel >= n { self.sel = n - 1; }
        }

        let mut launch: Option<usize> = None;
        let mut pin: Option<usize> = None;
        if enter && n > 0 {
            launch = Some(order[self.sel]);
        }

        let frame = Frame::none()
            .fill(Color32::BLACK)
            .stroke(Stroke::new(1.0, Color32::from_gray(55)))
            .rounding(22.0)
            .inner_margin(20.0);
        egui::CentralPanel::default().frame(frame).show(ctx, |ui| {
            let (hr, _) = ui.allocate_exact_size(vec2(ui.available_width(), 44.0), Sense::hover());
            dotfont::draw(ui.painter(), "SMTH", hr.left_top() + vec2(2.0, 4.0), 5.0, Color32::WHITE, Some(Color32::from_gray(26)));

            let resp = ui.add(
                egui::TextEdit::singleline(&mut self.query)
                    .hint_text("Search apps")
                    .desired_width(f32::INFINITY)
                    .margin(vec2(14.0, 10.0)),
            );
            resp.request_focus();
            if resp.changed() {
                self.sel = 0;
            }
            ui.add_space(10.0);

            let (apps, sel, pinned) = (&self.apps, self.sel, &self.pinned);
            egui::ScrollArea::vertical().auto_shrink([false, false]).show(ui, |ui| {
                if n_pinned > 0 {
                    section(ui, "PINNED");
                    grid(ui, &order[..n_pinned], 0, apps, sel, moved, pinned, &mut launch, &mut pin);
                }
                if n > n_pinned {
                    section(ui, if q.is_empty() { "ALL APPS" } else { "RESULTS" });
                    grid(ui, &order[n_pinned..], n_pinned, apps, sel, moved, pinned, &mut launch, &mut pin);
                }
                if n == 0 {
                    section(ui, "NO RESULTS");
                }
            });
        });

        if let Some(i) = pin {
            let name = self.apps[i].name.clone();
            if let Some(pos) = self.pinned.iter().position(|p| *p == name) {
                self.pinned.remove(pos);
            } else {
                self.pinned.push(name);
            }
            save_pinned(&self.pinned);
        }
        if let Some(i) = launch {
            apps::launch(&self.apps[i]);
            self.close(ctx);
        }
        if esc {
            self.close(ctx);
        }

        // Like the Windows Start menu: hide when focus is lost (tray mode only).
        if self.tray.is_some() {
            match ctx.input(|i| i.viewport().focused) {
                Some(true) => self.had_focus = true,
                Some(false) if self.had_focus => {
                    self.had_focus = false;
                    self.close(ctx);
                }
                _ => {}
            }
        }
    }
}

fn main() -> eframe::Result<()> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size(WIN)
            .with_decorations(false)
            .with_transparent(true)
            .with_always_on_top()
            .with_resizable(false)
            .with_taskbar(false),
        ..Default::default()
    };
    eframe::run_native("SMTH Start", options, Box::new(|cc| Ok(Box::new(Start::new(cc)))))
}
