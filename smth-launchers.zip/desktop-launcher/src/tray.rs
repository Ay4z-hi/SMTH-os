//! System tray (Windows). On Linux the tray is provided by the shell bar (waybar).
pub enum Cmd {
    Open,
    Quit,
}

#[cfg(windows)]
mod imp {
    use super::Cmd;
    use tray_icon::menu::{Menu, MenuEvent, MenuId, MenuItem};
    use tray_icon::{Icon, TrayIcon, TrayIconBuilder};

    pub struct Tray {
        open: MenuId,
        quit: MenuId,
        _icon: TrayIcon,
    }

    pub fn new() -> Option<Tray> {
        let menu = Menu::new();
        let open = MenuItem::new("Open SMTH Start", true, None);
        let quit = MenuItem::new("Quit", true, None);
        menu.append(&open).ok()?;
        menu.append(&quit).ok()?;

        // 32x32 icon: white ring + red dot
        let mut rgba = vec![0u8; 32 * 32 * 4];
        for y in 0..32usize {
            for x in 0..32usize {
                let (dx, dy) = (x as f32 - 15.5, y as f32 - 15.5);
                let r = (dx * dx + dy * dy).sqrt();
                let px: [u8; 4] = if r < 5.0 {
                    [0xFF, 0x00, 0x33, 0xFF]
                } else if (11.0..13.5).contains(&r) {
                    [0xFF, 0xFF, 0xFF, 0xFF]
                } else {
                    [0, 0, 0, 0]
                };
                let i = (y * 32 + x) * 4;
                rgba[i..i + 4].copy_from_slice(&px);
            }
        }
        let icon = Icon::from_rgba(rgba, 32, 32).ok()?;
        let tray = TrayIconBuilder::new()
            .with_menu(Box::new(menu))
            .with_tooltip("SMTH Start")
            .with_icon(icon)
            .build()
            .ok()?;
        Some(Tray { open: open.id().clone(), quit: quit.id().clone(), _icon: tray })
    }

    impl Tray {
        pub fn poll(&self) -> Option<Cmd> {
            while let Ok(ev) = MenuEvent::receiver().try_recv() {
                if ev.id == self.open {
                    return Some(Cmd::Open);
                }
                if ev.id == self.quit {
                    return Some(Cmd::Quit);
                }
            }
            None
        }
    }
}

#[cfg(not(windows))]
mod imp {
    use super::Cmd;
    pub struct Tray;
    pub fn new() -> Option<Tray> {
        None
    }
    impl Tray {
        pub fn poll(&self) -> Option<Cmd> {
            None
        }
    }
}

pub use imp::{new, Tray};
