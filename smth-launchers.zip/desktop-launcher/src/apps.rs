use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

#[derive(Clone)]
pub struct App {
    pub name: String,
    /// Linux: the Exec= line. Windows: path to the .lnk shortcut.
    pub target: String,
    pub terminal: bool,
}

pub fn load() -> Vec<App> {
    let mut apps = platform_load();
    apps.sort_by_key(|a| a.name.to_lowercase());
    apps.dedup_by(|a, b| a.name.eq_ignore_ascii_case(&b.name));
    apps
}

pub fn launch(app: &App) {
    platform_launch(app);
}

// ---------------- Linux ----------------
#[cfg(not(windows))]
fn platform_load() -> Vec<App> {
    let home = std::env::var("HOME").unwrap_or_default();
    let dirs = [
        "/usr/share/applications".to_string(),
        "/usr/local/share/applications".to_string(),
        "/var/lib/flatpak/exports/share/applications".to_string(),
        format!("{home}/.local/share/applications"),
        format!("{home}/.local/share/flatpak/exports/share/applications"),
    ];
    let mut out = Vec::new();
    for d in dirs {
        if let Ok(rd) = fs::read_dir(&d) {
            for e in rd.flatten() {
                let p: PathBuf = e.path();
                if p.extension().map(|x| x == "desktop").unwrap_or(false) {
                    if let Some(a) = parse_desktop(&p) {
                        out.push(a);
                    }
                }
            }
        }
    }
    out
}

#[cfg(not(windows))]
fn parse_desktop(path: &Path) -> Option<App> {
    let text = fs::read_to_string(path).ok()?;
    let (mut name, mut exec) = (None, None);
    let (mut hidden, mut term, mut main) = (false, false, false);
    for line in text.lines() {
        let line = line.trim();
        if line.starts_with('[') {
            main = line == "[Desktop Entry]";
            continue;
        }
        if !main {
            continue;
        }
        if let Some(v) = line.strip_prefix("Name=") {
            if name.is_none() {
                name = Some(v.to_string());
            }
        } else if let Some(v) = line.strip_prefix("Exec=") {
            exec = Some(v.to_string());
        } else if line == "NoDisplay=true" || line == "Hidden=true" {
            hidden = true;
        } else if line == "Terminal=true" {
            term = true;
        }
    }
    if hidden {
        return None;
    }
    Some(App { name: name?, target: exec?, terminal: term })
}

#[cfg(not(windows))]
fn platform_launch(app: &App) {
    let cleaned = app
        .target
        .split_whitespace()
        .filter(|t| !(t.starts_with('%') && t.len() == 2))
        .collect::<Vec<_>>()
        .join(" ");
    let Ok(parts) = shell_words::split(&cleaned) else { return };
    if parts.is_empty() {
        return;
    }
    let mut cmd = if app.terminal {
        let mut c = Command::new("alacritty");
        c.arg("-e").args(&parts);
        c
    } else {
        let mut c = Command::new(&parts[0]);
        c.args(&parts[1..]);
        c
    };
    let _ = cmd.stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null()).spawn();
}

// ---------------- Windows ----------------
#[cfg(windows)]
fn platform_load() -> Vec<App> {
    let mut out = Vec::new();
    for var in ["ProgramData", "APPDATA"] {
        if let Ok(base) = std::env::var(var) {
            let dir = Path::new(&base).join("Microsoft").join("Windows").join("Start Menu").join("Programs");
            scan(&dir, &mut out);
        }
    }
    out
}

#[cfg(windows)]
fn scan(dir: &Path, out: &mut Vec<App>) {
    let Ok(rd) = fs::read_dir(dir) else { return };
    for e in rd.flatten() {
        let p = e.path();
        if p.is_dir() {
            scan(&p, out);
        } else if p.extension().map(|x| x.eq_ignore_ascii_case("lnk")).unwrap_or(false) {
            let name = p.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
            if name.is_empty() || name.to_lowercase().contains("uninstall") {
                continue;
            }
            out.push(App { name, target: p.to_string_lossy().to_string(), terminal: false });
        }
    }
}

#[cfg(windows)]
fn platform_launch(app: &App) {
    use std::os::windows::process::CommandExt;
    let _ = Command::new("cmd")
        .args(["/C", "start", "", &app.target])
        .creation_flags(0x0800_0000) // CREATE_NO_WINDOW
        .spawn();
}
